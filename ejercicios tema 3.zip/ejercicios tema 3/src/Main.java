package com.open_bootcamp;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args){
        coche miCoche = new coche();
        miCoche.aumentarPuertas();
        System.out.println(miCoche.puertas);
        System.out.println(suma(2,4,5));
    }
    public static int suma(int a, int b, int c){

        return a + b + c;
    }
    public static class coche{
        public int puertas = 2;
        public void aumentarPuertas(){
            this.puertas++;
        }
    }

}